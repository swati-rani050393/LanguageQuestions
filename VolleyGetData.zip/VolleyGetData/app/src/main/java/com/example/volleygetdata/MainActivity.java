package com.example.volleygetdata;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView tvData;
RecyclerView rcvMain;
 private  String api="https://jsonplaceholder.typicode.com/posts";
         //"https://jsonplaceholder.typicode.com/posts/1/comments";

 ArrayList<User> allUserList;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    // tvData=findViewById(R.id.tv_data);

        rcvMain=findViewById(R.id.rcvMain);
        rcvMain.setLayoutManager(new LinearLayoutManager(this));
        getData();
  allUserList=new ArrayList<>();

    }
    private  void getData(){
      RequestQueue  requestQueue= Volley.newRequestQueue(this);
       StringRequest stringRequest =new StringRequest(Request.Method.GET ,api, new Response.Listener<String>() {
           @SuppressLint("SetTextI18n")
           @Override
           public void onResponse(String response) {
         JSONArray jsonArray=null;
               try {
                   jsonArray=new JSONArray(response);
               } catch (JSONException e) {
                   throw new RuntimeException(e);
               }

               for(int i=0;i<=jsonArray.length();i++){
             try{
                 JSONObject object=jsonArray.getJSONObject(i);
                 int useId =object.getInt("userId");
                 long id= object.getInt("id");
                 String title= object.getString("title");
                 String body= object.getString("body");
                User user=new User(useId,id,title,body);
                allUserList.add(user);
               // Log.e("api","onResponse"+allUserList.size());
                 //Toast.makeText(MainActivity.this, "UserId "+useId+"\n id "+id+"\n title "+title+"\n\n", Toast.LENGTH_SHORT).show();
            }catch (Exception e)
             {
                 e.printStackTrace();
             }
         }
               rcvMain.setAdapter(new MyAdapter(MainActivity.this,allUserList));

           //  tvData.setText("Response is "+response.toString());
               Log.e("api","Response"+ response);
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
          Log.e("api","onErrorResponse"+error.getLocalizedMessage());
           }
       });
       requestQueue.add(stringRequest);

    }
}