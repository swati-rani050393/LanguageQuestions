package com.example.volleygetdata;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder>
{
    Activity activity;
    ArrayList<User> allUserList;

    public MyAdapter(Activity activity, ArrayList<User> allUserList) {
        this.activity = activity;
        this.allUserList = allUserList;
    }

    @NonNull
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
  View view= LayoutInflater.from(activity).inflate(R.layout.item_view,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {
//        if (holder.bodyTxt != null) {
//            holder.bodyTxt.setText(allUserList.get(position).getBody());
//        }
//        if (holder.idTxt != null) {
//            holder.idTxt.setText(String.valueOf(allUserList.get(position).getUserId()));
//        }
//        if (holder.titleTxt != null) {
//            holder.titleTxt.setText(allUserList.get(position).getTitle());
//        }
    holder.bodyTxt.setText( allUserList.get(position).getBody());
    holder.idTxt.setText(String.valueOf(allUserList.get(position).getId()) );
     holder.titleTxt.setText(allUserList.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return allUserList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView bodyTxt,titleTxt,idTxt;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bodyTxt=itemView.findViewById(R.id.bodytxt);
            idTxt=itemView.findViewById(R.id.idtxt);
            titleTxt=itemView.findViewById(R.id.titletxt);
        }
    }
}
